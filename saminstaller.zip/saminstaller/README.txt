saminstaller —— SamAI 统一安装器本体
  python saminstaller.py list
  python saminstaller.py install openbox            # 静默安装版（win: Inno /SILENT）
  python saminstaller.py install openbox --portable # 便携版：解包即用，免管理员权限
依赖：Python 3.8+，零第三方依赖（纯标准库）。catalog 三渠道自动回退。
