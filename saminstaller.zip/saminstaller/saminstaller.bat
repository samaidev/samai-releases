@echo off
python "%~dp0saminstaller.py" %*
